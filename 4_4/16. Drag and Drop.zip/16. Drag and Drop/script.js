"use strict";

const fill = document.querySelector(".fill");
const empties = document.querySelectorAll(".empty");

