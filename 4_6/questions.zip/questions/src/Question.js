import React, { useState } from "react";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";
const Question = () => {
  return (
    <article className="question">
      <header>
        <h4>title</h4>
        <button className="btn">icons</button>
      </header>
      <p>Info</p>
    </article>
  );
};

export default Question;
